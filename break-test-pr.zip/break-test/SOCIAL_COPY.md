# Break Test — Social launch copy

## LinkedIn

Your tests pass. But what happens when the environment changes?

**Break Test** is a standalone skill for coding agents that helps uncover realistic build and test failures before they surprise you in CI or production.

It works through an evidence-first process:
- isolate the work from the developer's checkout
- record the untouched build/test baseline
- probe realistic failure conditions
- reproduce issues with exact commands and observed output
- apply only minimal fixes that pass both the reproduction and the project gate
- report what was tested, what was fixed, and what remains uncertain

No invented findings. No “fixed” claims without verification. No weakening tests just to get a green check.

I'm sharing Break Test as a free skill. The full skill is available in this repository; the quick-start guide explains how to use it.

If you try it, I'd genuinely value feedback on the workflow and the kinds of issues it helps you uncover.

#AIEngineering #SoftwareEngineering #Testing #DeveloperTools #CodingAgents

## Facebook

A project can pass its tests and still break in a clean checkout, on another machine, or under a different environment.

I put together **Break Test** — a free, standalone skill for coding agents. It checks realistic failure conditions, asks for evidence before calling something a bug, and keeps fixes only when they are actually verified against the project's baseline.

The important part is the discipline: work in isolation, reproduce first, make the smallest safe fix, and report honestly what was and wasn't tested.

The full skill and a short quick-start guide are available in the repository. I'd love to hear what you think after trying it.

## X

Tests pass. But will the build survive a clean checkout, a different environment, or flaky test order?

Break Test is a free skill for coding agents: isolate, probe, reproduce, fix minimally, and verify against baseline. Evidence over guesses.

## Threads / Instagram caption

Passing tests is a good start. It isn't the whole reliability story.

**Break Test** is a free skill for coding agents that probes realistic ways a build or test suite can fail — then requires reproducible evidence before reporting a finding or keeping a fix.

Isolated work. Exact repro commands. Minimal fixes. Verification against baseline. Honest reporting of what remains untested.

The full skill and quick-start guide are in the repository. Try it and tell me what it finds.

## Optional Fetchproof connection (use only if you want to link both projects)

I also see a useful place to connect this with Fetchproof: position the two as complementary stages, not substitutes. Fetchproof can be introduced as part of the preparation/research side of a project; Break Test focuses on adversarially checking the resulting build and test workflow. Avoid claiming that one removes the need for the other unless you have measured evidence.

## Short carousel post text

I made a free skill for coding agents that doesn't stop at “the tests passed.” Break Test looks for realistic failure conditions, reproduces them with commands and observed output, and keeps fixes only when they pass verification against the original baseline. Swipe for the workflow; the full skill and quick start are in the repository.
