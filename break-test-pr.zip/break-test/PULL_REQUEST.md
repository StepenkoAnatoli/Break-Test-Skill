## Summary

Add **Break Test**, a standalone skill that helps coding agents identify and reproduce realistic build/test reliability failures, apply minimal verified fixes, and report remaining risks with evidence.

## Included

- `SKILL.md` — complete skill specification (keep the full procedure intact)
- `README.md` — project overview and workflow summary
- `QUICKSTART.md` — concise setup, invocation, and safety guide
- `linkedin-carousel.pdf` — five-slide social explainer
- `SOCIAL_COPY.md` — launch copy for LinkedIn, Facebook, X, and Threads/Instagram

## Key behavior

- Isolates probes from the user's checkout by default.
- Records the untouched build/test gate as a baseline.
- Probes realistic failure modes and records exact commands.
- Requires reproduction before calling an issue a confirmed finding.
- Keeps fixes only when the repro and gate pass against baseline.
- Does not weaken tests to create a green result.
- Reports skipped probes, unverified risks, and observed evidence honestly.

## Review notes

- Keep `SKILL.md` as the source of truth; the quick-start and social materials are summaries, not replacements.
- Confirm the skill's supported metadata/installation layout matches the target agent platform before merging.
- Check that links in the README point to the final repository paths.
- No claims of exhaustive testing or guaranteed reliability are made.
